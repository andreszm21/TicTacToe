//
//  tictactoeApp.swift
//  tictactoe
//
//  Created by AMStudent on 9/20/21.
//

import SwiftUI

@main
struct tictactoeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
